package com.abnamro.apps.referenceandroid;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isClickable;
import static androidx.test.espresso.matcher.ViewMatchers.withContentDescription;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.test.espresso.ViewAssertion;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class) //this is for running with Junit runner
public class LaunchedScreenIconsTest {

    @Rule // this is used to start the activity or close the activity.
    // Here we are using ActivityScenarioRule to reach to the MainActivity class
    public ActivityScenarioRule<MainActivity> mActivity=
            new ActivityScenarioRule <>(MainActivity.class);


    @Test
    //1. Locate the elements on screen
    //2. Perform the action on this element
    //3. Assert the result with expected output
    public void clickScreenButton_EmailIcon() {
        //id: fab --for email icon in the right bottom corner

        onView(withId(R.id.fab)).
                perform(click());
    }

    @Test
    //text: ReferenceAndroid --for toolbar text of application
    public void checkToolbarTitleText() {
        onView(withText(R.string.app_name)).
                check(matches(withText("ReferenceAndroid")));
    }

    @Test
    //contentDescription: More options --for Settings icon-three dots check if it is clickable
    public void checkToolbarContentDescription_ThreeDotButtonsIcon(){
        onView(withContentDescription("More options")).check(matches(isClickable()));


    }

}
